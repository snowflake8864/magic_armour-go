type AgentModel struct {
	model.BaseModel
	Uuid                   string `json:"uuid"`
	HostName               string `gorm:"column:host_name" json:"host_name"`
	MacId                  string `gorm:"column:mac_id" json:"mac_id"`
	Ip                     string `json:"ip"`
	ClientIp               string `gorm:"column:client_ip" json:"client_ip"`
	OsName                string `gorm:"column:os_name" json:"os_name"`
	PlatformType          string `gorm:"column:platform_type" json:"platform_type"`
	OsType                string `gorm:"column:os_type" json:"os_type"`
	MemSize               string `gorm:"column:mem_size" json:"mem_size"`
	HdSize                string `gorm:"column:hd_size" json:"hd_size"`
	CpuSize               string `gorm:"column:cpu_size" json:"cpu_size"`
	AgentStartAt         string `gorm:"column:agent_start_at" json:"agent_start_at"`
	OsStartAt            string `gorm:"column:os_start_at" json:"os_start_at"`
	Ver                    string `json:"ver"`
	Auth                   string `json:"auth"`
	Is_online              int    `gorm:"column:os_start_at" json:"is_online"`
	Online_start_at        string `gorm:"column:online_start_at" json:"online_start_at"`
	Live_at                string `gorm:"column:live_at" json:"live_at"`
	Upgrade_ver            string `gorm:"column:upgrade_ver" json:"upgrade_ver"`
	Admin_id               int    `gorm:"column:admin_id" json:"admin_id"`
	Dept_id                int    `gorm:"column:dept_id" json:"dept_id"`
	Agent_type_id          int    `gorm:"column:agent_type_id" json:"agent_type_id"`
	Alias_name             string `gorm:"column:alias_name" json:"alias_name"`
	Contact_name           string `gorm:"column:contact_name" json:"contact_name"`
	Contact_tel            string `gorm:"column:contact_tel" json:"contact_tel"`
	Remark                 string `gorm:"column:remark" json:"remark"`
	Process_switch         int    `gorm:"column:process_switch" json:"process_switch"`
	Process_mode           int    `gorm:"column:process_mode" json:"process_mode"`
	Dll_switch             int    `gorm:"column:dll_switch" json:"dll_switch"`
	Dll_mode               int    `gorm:"column:dll_mode" json:"dll_mode"`
	Tamper_switch          int    `gorm:"column:tamper_switch" json:"tamper_switch"`
	Tamper_mode            int    `gorm:"column:tamper_mode" json:"tamper_mode"`
	Blackmail_switch       int    `gorm:"column:blackmail_switch" json:"blackmail_switch"`
	Blackmail_mode         int    `gorm:"column:blackmail_mode" json:"blackmail_mode"`
	Port_switch            int    `gorm:"column:port_switch" json:"port_switch"`
	Plug_switch            int    `gorm:"column:plug_switch" json:"plug_switch"`
	Plug_port_config       string `gorm:"column:plug_port_config" json:"plug_port_config"`
	Plug_login_config      string `gorm:"column:plug_login_config" json:"plug_login_config"`
	Usb_switch             int    `gorm:"column:usb_switch" json:"usb_switch"`
	Usb_mode               int    `gorm:"column:usb_mode" json:"usb_mode"`
	Syslog_dns_switch      int    `gorm:"column:syslog_dns_switch" json:"syslog_dns_switch"`
	Syslog_outer_switch    int    `gorm:"column:syslog_outer_switch" json:"syslog_outer_switch"`
	Syslog_inner_switch    int    `gorm:"column:syslog_inner_switch" json:"syslog_inner_switch"`
	Syslog_process_switch  int    `gorm:"column:syslog_process_switch" json:"syslog_process_switch"`
	Syslog_login_switch    int    `gorm:"column:syslog_login_switch" json:"syslog_login_switch"`
	Outreach_alarm_switch  int    `gorm:"column:outreach_alarm_switch" json:"outreach_alarm_switch"`
	Self_protection_switch int    `gorm:"column:self_protection_switch" json:"self_protection_switch"`
	Kernel_upgrade_switch  int    `gorm:"column:kernel_upgrade_switch" json:"kernel_upgrade_switch"`
	Common_time            int    `gorm:"column:common_time" json:"common_time"`
	Fast_time              int    `gorm:"column:fast_time" json:"fast_time"`
	Auto_white_switch      int    `gorm:"column:auto_white_switch" json:"auto_white_switch"`
	Alarm_ai_switch        int    `gorm:"column:alarm_ai_switch" json:"alarm_ai_switch"`
	Login_solve_switch     int    `gorm:"column:login_solve_switch" json:"login_solve_switch"`
	Login_solve_config     string `gorm:"column:login_solve_config" json:"login_solve_config"`
	Hardware_switch        string `gorm:"column:hardware_switch" json:"hardware_switch"`
	Hardware_time          string `gorm:"column:hardware_time" json:"hardware_time"`
	Process_flush_at       string `gorm:"column:process_flush_at" json:"process_flush_at"`
	Dll_flush_at           string `gorm:"column:dll_flush_at" json:"dll_flush_at"`
}